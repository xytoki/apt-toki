# 通过域名访问内网的  Web 服务

有时想要让其他人通过域名访问或者测试我们在公司内网搭建的 Web 服务，但是由于公司内网服务器没有公网 IP，无法在外网直接访问公司内网的 Web 服务。

通过搭建 frp 内网穿透服务，就可以实现这一目的。

{% include "../include/frp-install.md" %} 

## 配置 frp 服务器

### 监听设置

进入 frp 服务器节点的【frp内网穿透服务器】应用，进入“设置”菜单：

设置监听 IP 为所有 IP，监听端口为 7000：
![](images/frp-server-01.png)

### Web 穿透设置

启用 Web 穿透，设置 HTTP 访问端口为 8080：
![](images/frp-server-02.png)

### 启动/重启服务

启动/重启 frp 内网穿透服务器服务，使配置生效。

## 配置 frp 客户端

进入 frp 客户端节点的 【frp 内网穿透客户端】应用。

### 全局设置

进入全局设置页面，设置 frp 服务器地址和端口，（这边的值要和 frp 服务器配置步骤中配置的值一致）
![](images/frpc-global-01.png)

### 新建 HTTP 代理

进入“代理管理”，点击“新建代理”，“代理类型”为 HTTP：
![](images/http-01.png)

假定内网的 Web 服务域名为：www.yourdomain.com，Web 服务器 IP 地址为：127.0.0.1，端口为：80，那么对应的设置如下：
![](images/http-02.png)

请注意：如果在 frp 客户端所在服务器上，解析的 Web 服务域名得到的 IP 地址，不是 Web 服务器 IP，那么您需要在 frp 客户端服务器上修改 /etc/hosts，做 Host 绑定，如上例中需要增加以下一行：
> 127.0.0.1  www.yourdomain.com

### 启动/重启服务

启动/重启 frp 内网穿透客户端服务，使配置生效。

## 在外网访问内网 Web 服务的方式

设置完成后，请将域名解析到外网服务器 IP 上。

解析成功后，可以在浏览器上使用以下 URL 地址访问内网的 Web 服务：
> http://www.yourdomain.com:8080/


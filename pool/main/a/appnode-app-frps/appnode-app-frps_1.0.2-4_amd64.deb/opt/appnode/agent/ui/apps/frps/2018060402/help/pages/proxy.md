# 通过内网服务器代理访问网络

frp 内置了 http proxy 和 socks5 支持，可以使其他服务器通过 frp 客户端所在服务器的网络访问网络。

{% include "../include/frp-install.md" %} 

{% include "../include/frp-server.md" %}

## 配置 frp 客户端

进入 frp 客户端节点的【frp 内网穿透客户端】应用。

### 全局设置

进入全局设置页面，设置 frp 服务器地址和端口，（这边的值要和 frp 服务器配置步骤中配置的值一致）
![](images/frpc-global-01.png)

### 新建 TCP 代理

进入“代理管理”，点击“新建代理”，“代理类型”为 TCP：
![](images/proxy-01.png)
![](images/proxy-02.png)

### 启动/重启服务

启动/重启 frp 内网穿透客户端服务，使配置生效。


## 代理访问 HTTP 服务

设置完成后，可以在外网使用以下 HTTP 代理信息访问网络：
* 代理服务器 IP 地址：为外网 frp 服务器的 IP 地址
* 端口：6000（在 frp 客户端中新建代理时设置的值）
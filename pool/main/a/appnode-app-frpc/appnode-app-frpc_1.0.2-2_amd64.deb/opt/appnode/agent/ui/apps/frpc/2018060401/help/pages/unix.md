# 转发 Unix 域套接字

可以通过 frp 实现通过 TCP 端口访问内网的 unix 域套接字，比如和 Docker Daemon 通信。

{% include "../include/frp-install.md" %} 

{% include "../include/frp-server.md" %}

## 配置 frp 客户端

进入 frp 客户端节点的【frp 内网穿透客户端】应用。

### 全局设置

进入全局设置页面，设置 frp 服务器地址和端口，（这边的值要和 frp 服务器配置步骤中配置的值一致）
![](images/frpc-global-01.png)

### 新建 TCP 代理

进入“代理管理”，点击“新建代理”，“代理类型”为 TCP：
![](images/unix-01.png)
![](images/unix-02.png)

### 启动/重启服务

启动/重启 frp 内网穿透客户端服务，使配置生效。

## 通过 curl 命令查看内网 Docker 版本信息

设置完成后，可以在外网使用以下命令访问内网的 Unix 套接字服务（x.x.x.x 为外网 frp 服务器的 IP 地址）：
> curl http://x.x.x.x:6000/version
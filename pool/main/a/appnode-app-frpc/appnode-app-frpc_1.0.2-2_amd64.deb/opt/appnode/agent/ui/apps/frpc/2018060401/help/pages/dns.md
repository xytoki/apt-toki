# 转发 DNS 查询请求

DNS 查询请求通常使用 UDP 协议，frp 支持对内网 UDP 服务的穿透，配置方式和 TCP 基本一致。

{% include "../include/frp-install.md" %}

{% include "../include/frp-server.md" %}

## 配置 frp 客户端

进入 frp 客户端节点的【frp 内网穿透客户端】应用。

### 全局设置

进入全局设置页面，设置 frp 服务器地址和端口，（这边的值要和 frp 服务器配置步骤中配置的值一致）
![](images/frpc-global-01.png)

### 新建 UDP 代理

进入“代理管理”，点击“新建代理”，“代理类型”为 UDP：
![](images/dns-01.png)

这里使用 Google 的 Public DNS 服务器 8.8.8.8 作为外网 DNS 查询的转发目标：
![](images/dns-02.png)

### 启动/重启服务

启动/重启 frp 内网穿透客户端服务，使配置生效。

## 在外网通过内网的  DNS 查询

通过 dig 测试 UDP 包转发是否成功，预期会返回 www.google.com 域名的解析结果

对应的 SSH 命令为（x.x.x.x 为外网 frp 服务器的 IP 地址）：
> dig @x.x.x.x -p 6000 www.google.com

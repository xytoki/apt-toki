# 访问内网的 SSH 服务

有时想要在外网通过 SSH 连接到公司内网的服务器，但是由于公司内网服务器没有公网 IP，无法在外网直接访问公司内网的 SSH 服务。

通过搭建 frp 内网穿透服务，就可以实现这一目的。

{% include "../include/frp-install.md" %}

{% include "../include/frp-server.md" %}


## 配置 frp 客户端

进入 frp 客户端节点的【frp 内网穿透客户端】应用。

### 全局设置

进入全局设置页面，设置 frp 服务器地址和端口，（这边的值要和 frp 服务器配置步骤中配置的值一致）
![](images/frpc-global-01.png)

### 新建 TCP 代理

进入“代理管理”，点击“新建代理”，“代理类型”为 TCP：
![](images/ssh-01.png)
![](images/ssh-02.png)

### 启动/重启服务

启动/重启 frp 内网穿透客户端服务，使配置生效。

## 外网 SSH 连接方式

设置完成后，可以在外网使用以下信息连接内网的 SSH 服务：
* IP地址：为外网 frp 服务器的 IP 地址
* 端口：6000（在 frp 客户端中新建代理时设置的值）

对应的 SSH 命令为（x.x.x.x 为外网 frp 服务器的 IP 地址）：
> ssh -oPort=6000 root@x.x.x.x
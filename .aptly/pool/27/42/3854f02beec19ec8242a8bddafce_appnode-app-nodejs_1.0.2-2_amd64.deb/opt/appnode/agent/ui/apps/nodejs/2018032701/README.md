Node.js -- 受控端应用集 --  AppNode 受控端
=======================

*  前端样式：bootstrap
*  模版引擎：angularjs

##  Node.js
compass配置：
ln -s ../ccenter-ui/wrap-dev/app/config.rb config.rb 
ln -s ../agent-appui-bootstrap/.gitignore .gitignore





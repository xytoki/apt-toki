/*! 
 * AppNode 进程管理 - v0.0.1 
 * Copyright  2014-2017  Quyun Inc
 * Released on 2017-09-01 19:03:07
 */
define("agent/procmgr/controllers/procmgr",["angular","agent/procmgr-proto-services"],function(r){"use strict";return r.module("agent/procmgr/procmgr.controller",["procmgr.proto.services"]).controller("DefaultCtrl",["$scope","WebSet",function(r,e){r.defaultMg={init:function(){r.agentParams=e.agent.init()}},r.defaultMg.init()}])}),require(["angular","agent/procmgr/controllers/procmgr"],function(r){"use strict";var e=r.module("procmgr"+g_appNode.app.ngAgentApp,["agent/procmgr/procmgr.controller"]);r.bootstrap(document.getElementById(g_appNode.app.singleAppID),[e.name])}),define("procmgr-main",function(){});